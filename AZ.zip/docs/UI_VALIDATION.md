# UI consistency validation

## Added problems: 27816 and 1989 (2026-09-22)

- Added island BFS (27816) and palindrome comparison (1989) using the shared theme, layout, input controls, keyboard shortcuts and desktop/mobile player. Python examples and sample files come from the supplied archives; local `sys.stdin` file redirection is omitted from the displayed code.
- Kept 9367 first in the catalog, followed by 1989 and 27816. Updated 9367 with all four supplied individual samples and the supplied N/size constraints.
- All supplied outputs match: 27816 → 2, 1, 18; 1989 → 1, 0, 1, 0, 1, 0, 1, 0, 0, 1; 9367 → 5, 3, 1, 3.
- Algorithm checks also cover 20×20 all-water/all-land maps and odd/even, matching/mismatching, mixed-case and numeric palindrome examples.
- Browser checks cover sample selection, end navigation, replay/pause, direct input errors, matching desktop/mobile output, current-code scrolling, and internal scrolling of a 20×20 board. No page overflow at 360, 390, 430, 768, 1024, 1280 and 1440px for the three affected problems; maximum-board behavior checked at 375px.
- Shared low-specificity defaults provide board padding, internal overflow and state-cell layout without overriding existing problem-specific styles. Existing 5102 mobile layout/end navigation checked after the shared change.
- All 23 pages pass unique-ID and local resource checks. New scripts pass JavaScript syntax parsing. Browser checks use desktop Chrome viewport overrides, not physical mobile devices.

## 2026-09-22 review (21 problems)

- Reviewed all 21 problem pages at 1440px and 390px: no document horizontal overflow; end navigation disables next. Mobile pages expose one input editor and full state details.
- Migrated 9367 to the shared desktop/mobile UI, code renderer, playback controls, sample selection and inline input errors. Moved its catalog entry to first position.
- Fixed 5102 code tracking using the shared viewport scroll helper on every step change, plus sample selection, playback labels, speed rescheduling, input validation and testcase labels.
- Verified 5102 active line 22 is inside the code viewport on desktop (scrollTop approximately 262px) and mobile (approximately 430px). Full sample outputs: 2, 4, 3; final testcase label is #3. Invalid node IDs show a Korean inline error.
- Verified all three 9367 samples: full sample outputs 5, 3, 1, 3; increasing sample 5; reset sample 3. Checked empty input, zero testcase count, missing values, extra values and Infinity errors; replay and pause; desktop/mobile output synchronization.
- Inspected desktop 5102 and 320px mobile 9367 screenshots. Additional 9367 layout checks at 360, 760, 761 and 1024px found no document overflow and one visible input editor.
- All 25 JavaScript files passed syntax parsing. All 21 HTML pages passed unique-ID and local stylesheet/script resource checks. No JavaScript console errors in the modified-page checks.
- Browser validation used desktop Chrome viewport overrides; physical mobile devices were not tested. The all-page pass checks shared layout and end navigation, not every algorithm input combination.

Base: `9225024b893e66ee3bdf0c2a357d73db606a61a4`

## Shared UI contract

Load `assets/ui.css` after problem styles, and `assets/ui.js` after the problem script. Board geometry and algorithm-specific state colors remain in problem styles; shared typography, panels, controls, responsive spacing and code highlighting use one presentation layer.

At 760px and below, the existing input panel, speed control, chapter navigation (where present), and full state panel move into the mobile layout. They are not cloned, so there is one input draft and one set of event handlers. The full state panel is available under “전체 변수와 상태 보기”. Resizing restores these elements to their desktop positions.

Playback uses each problem's existing timer and navigation functions. Labels use text instead of pictographs. Page shortcuts do not consume events originating in form controls, links, buttons, summaries, or editable content.

## Checks performed

- All 10 problem pages at 320, 760, 761, 1024 and 1440px: no document horizontal overflow, one input panel, one visible main heading, full state panel present.
- All 10 mobile pages: previous/next, reset, end, playback and pause; end disables next. Problem outputs inspected for applicable pages.
- 5356: invalid input displays an inline error; valid five-line A/B/C/D/E input produces ABCDE. Input draft and 2x speed survive desktop/mobile layout transitions. Full state details open.
- 1215 desktop: native timeline End reaches the last step; next disables; reset and ArrowRight navigate correctly.
- Home: number/title search, empty results, result count, clear button and navigation; card numbers remain stable while filtering. 320px visual inspection.
- JavaScript syntax, local HTML resource links, unique IDs, and absence of extended pictographs checked.
- Browser error logs inspected: no JavaScript errors during the checks.

These checks use the desktop app's Chromium browser with viewport overrides. Physical iOS/Android devices and browser-specific behavior outside Chromium have not been tested.

## Repeat after changes

1. Open each problem at a narrow viewport and exercise playback, timeline, sample selection and input application.
2. Enter an unsubmitted draft and change speed. Resize across 760px and confirm both survive.
3. Open full variable details on mobile. Resize to desktop and confirm the state panel returns to the workspace.
4. Check 320px and 761px widths, then run the problem to its last step.
5. Search the home catalog, clear it, and open a result.

## 2026-09-29: SWEA 5189 electronic cart

- Added problems/5189 with the accepted recursive Python solution, all three supplied samples, and a searchable home catalog entry. Uses the existing shared theme, code renderer, playback, copy button, responsive controls and keyboard shortcuts.
- Visualizes directed matrix costs, place numbers versus zero-based indices, current route, recursion frames, visited flags and their restoration, return-to-office cost, completed-route count and minimum route.
- Both JavaScript exploration and the displayed Python produce 89, 96 and 139. Trace checks cover route uniqueness, visit count, accumulated energy and visited restoration. Fifteen generated asymmetric matrices (N=3..7) match a separate permutation enumerator.
- N=10 visits all 362,880 routes and returns 1,000 for all off-diagonal costs of 100. Snapshot storage is bounded (up to 2,200 detailed frames per case, a total detail budget of 12,000, plus summary/output frames); calculation still covers every route. Summary frames explicitly identify omitted animation and do not highlight a Python line. The example does not use cost pruning.
- Browser checks passed: all individual/full samples, manual input/error recovery, previous/next/reset/end/seek, replay/pause/speed, mobile player, matching desktop/mobile values and source lines, full mobile state, and active code scrolling. Switching from a large 50-case calculation to a sample cancels the old calculation.
- No document overflow at 1440, 1280, 1024, 768, 430, 390, 375 and 360px. At 360px the N=10 matrix scrolls internally. One input editor is visible; unsubmitted input and playback speed survive breakpoint changes.
- Home searches by number, title and backtracking keyword, empty results, and navigation passed. No browser console errors or resource failures; unique IDs, local asset links, JS syntax and git whitespace checks passed.
- Browser checks use desktop Chromium with viewport overrides, not physical mobile devices.

## 2026-09-29: SWEA 5188 minimum sum

- Added problems/5188 and a searchable home catalog entry. The displayed Python preserves the user's DFS, downward-before-right traversal, ans pruning, and per-cell best pruning. Local file redirection is omitted from the displayed code.
- The board shows both cell values and best arrival records. Separate colors, explanations, counters and jump buttons distinguish ans pruning, best pruning and answer updates. Current paths, call frames and the best complete path show that distance belongs to each call while best and ans persist after returning.
- JavaScript exploration and the displayed Python match all supplied sample outputs: 15, 18 and 33. Seventy generated grids match an independent iterative DP reference. Sample trace checks cover path sums, legal moves, both pruning predicates, historical snapshot immutability and best-path sums.
- Maximum-size inputs (N=13, T=50, all cells 10) return 250 for every case. At most 12,000 detailed animation frames plus per-case summary/output frames are retained; DFS calculation continues to completion. Summary and implicit return frames do not falsely highlight a Python statement. Each explicit return is mapped to its own source line.
- Browser checks passed for all sample selections, direct input/error recovery, both pruning jumps, answer-update jumps, previous/next/reset/end/seek, playback/pause/speed/replay, mobile controls, source copying, keyboard shortcuts and cancelling a large calculation by choosing a sample.
- No document overflow at 320, 360, 390, 760, 761, 1024 and 1440px. The N=13 board scrolls internally on mobile. Input drafts and playback speed survive layout changes; the active code line scrolls into view after crossing the mobile breakpoint. Desktop/mobile output and explanations remain synchronized; full mobile state is available.
- Home searches by number, title and pruning keyword, empty results, clearing and navigation passed. JavaScript syntax, unique IDs, source anchors, local resource links and git whitespace checks passed. No browser console errors were reported.
- Browser checks used headless Chromium with viewport overrides, not physical mobile devices.
